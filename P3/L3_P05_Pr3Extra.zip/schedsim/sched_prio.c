#include <sched.h>

/*
* Se establece un criterio de la cola de procesos segun los cores de CPU 
*/
void sched_init_prio(void) {
   int cpu,prio;

for (cpu=0;cpu < nr_cpus; cpu++){
   for(prio=0;prio<MAX_PRIO;prio++){
   init_slist(&get_runqueue_cpu(cpu)->tasks_prio[prio], sizeof(task_t),offsetof(task_t,rq_links));
}

}
}

//No precisa
void sched_destroy_prio(void) {}

static void task_new_prio(task_t* t) { }

static task_t* pick_next_task_prio(runqueue_t* rq,int cpu) {
    task_t* t = NULL;
    bool haSacado = FALSE;
    int i;
    for(i = 0; (i < MAX_PRIO)&&(!haSacado); i++) {
	if(!is_empty_slist(&rq->tasks_prio[i])) {
	//Si la lista no esta vacia se encola la tarea a la cabeza y se marca la salida
           t = head_slist(&rq->tasks_prio[i]);
	   haSacado = TRUE;
        }

        if (t) {
         //Eliminamos la tarea de la cola de proceso y la asignamos como tarea actual
        remove_slist(&rq->tasks_prio[i],t);
        t->on_rq=FALSE;
        rq->cur_task=t;
    }

    }
 
    
    return t;
}
/*
*  Diferencia de los valores de prioridad de entrada de CPU entre dos tareas
*/
static int compare_tasks_cpu_burst(void *t1,void *t2) {
	//Asignar varibles locales para el calculo
	task_t* tsk1=(task_t*)t1;
	task_t* tsk2=(task_t*)t2;
	return tsk1->prio-tsk2->prio;
}

/*
* Proceso de encolado de una tarea a la cola de procesos de unaCPU
*/
static void enqueue_task_prio(task_t* t,int cpu, int runnable) {
    //se recibe la cola de proceso de la CPU indicada
    runqueue_t* rq=get_runqueue_cpu(cpu);
    
    //si la tarea se ecuentra ya encolada o en espera, se finaliza el proceso
    if (t->on_rq || is_idle_task(t))
        return;

    //valores de flag de la tarea e insercion de tarea al principio de la cola de procesos
    if (t->flags & TF_INSERT_FRONT){
        //Limpiar flag
        t->flags&=~TF_INSERT_FRONT;
	//Encolar tarea con priotidad al principio de la cola de procesos
        insert_slist_head(&rq->tasks_prio[t->prio], t);    
    }
    else
	//Encolar directamente tarea con priotidad al final de la cola de procesos
        insert_slist(&rq->tasks_prio[t->prio], t);
    //Independientemente del punto deentrada, marcar tarea como encolada
    t->on_rq=TRUE;
            
    //Si la tarea no pudo ejecutarse anteriormente, actualizar el numero de tareas ejecutables en la cola de proceso
    if (!runnable){
	//tomamos la tarea actual
        task_t* current=rq->cur_task;
	//incrementar el numero de tareas ejecutables en la CPU
        rq->nr_runnable++;
	//Actualizamos el valor de la CPU por la nueva CPU asiganada
        t->last_cpu=cpu;	
        
        //Replanificar si la tarea tiene una rafaga de CPU mas corta que la actual
        // y no es una tarea en espera y la replanificación esta disponible
        if (preemptive_scheduler && !is_idle_task(current) && t->prio<current->prio) {
	//marcamos la necesidad de replanificar
            rq->need_resched=TRUE;
	//otra tarea con la misma prioridad despierta en el evento para evitar situciones "injustas"
            current->flags|=TF_INSERT_FRONT; 

        }
    }     
}


static void task_tick_prio(runqueue_t* rq,int cpu){
    //Obtenemos la tarea actual
    task_t* current=rq->cur_task;
    
	//Si la tarea actual esta en espera
    if (is_idle_task(current))
        return;

    //Si latarea esta lista para bloquearse o terminar, se decrementan los procesos en la CPU
    if (current->runnable_ticks_left==1) 
        rq->nr_runnable--; // The task is either exiting or going to sleep right now    
}

/*
* Proceso de expropiacion de tareas de la cola de proceso
*/
static task_t* steal_task_prio(runqueue_t* rq,int cpu){

    
    task_t* t = NULL;
    bool haSacado = FALSE;
    int i;

	//recorremos la cola de prioridades 
    for(i = MAX_PRIO; (i > 0)&&(!haSacado); i--) {
	if(!is_empty_slist(&rq->tasks_prio[i])) {
	//tomamos el ultimo elemento de la lista y marcamos su salida
           t = tail_slist(&rq->tasks_prio[i]);
	   haSacado = TRUE;
        }

        if (t) {
	//Si el elemento es valido se suprime de la lista
        remove_slist(&rq->tasks_prio[i],t);

	//Desmarcamos la tarea "en cola" y decrementamos el numero de tareas ejecutables en la CPU
        t->on_rq=FALSE;
        rq->nr_runnable--;
        }
    }
    return t;    
}

sched_class_t prio_sched = {
	.sched_init=sched_init_prio,
	.sched_destroy=sched_destroy_prio,
	.task_new=task_new_prio,
	.pick_next_task=pick_next_task_prio,
	.enqueue_task=enqueue_task_prio,
	.task_tick=task_tick_prio,
	.steal_task=steal_task_prio
};
