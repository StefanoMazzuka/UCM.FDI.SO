#!/bin/bash

nameSched=( "RR" "SJF" "FCFS" "PRIO" )

echo '¿Qué ficherodeseas simular?'
echo 'Indique una ruta del fichero: '
read fichero

while [ ! -f $fichero ]; do
   echo -e "\nERROR: El fichero no existe o esta inaccesible.\n"
   echo 'Inserte un nuevo ficero que simular'
   read fichero   
done

echo 'Indique cuantas CPU deben simuarse (Max 8): '
read maxCPUs

while [ $maxCPUs -gt 8 ]; do
   echo -e  "\nError: numero de CPU incorrecto.\n"
   echo 'Inserte un valor valido (Max 8): '
   read maxCPUs
done

if [ -d resultados ]; then
rm -r resultados
fi
mkdir resultados


for item in "${nameSched[@]}"; do
   for (( cpus = 1 ; $cpus<=$maxCPUs; cpus++ )) do
      ./schedsim -n "$cpus" -s "$item" -i "$fichero"
      for((i=0 ; $i < $cpus ; i++)) do
         mv CPU_$i.log resultados/"$item"-CPU-$i.log
      done
   done

 
   cd ../gantt-gplot
      
   for((j=0; $j <$maxCPUs; j++)) do
      ./generate_gantt_chart ../schedsim/resultados/"$item"-CPU-"$j".log
   done
   cd ../schedsim
done
